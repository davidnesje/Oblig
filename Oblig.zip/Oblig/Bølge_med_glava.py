import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation

#Definerer antall grid til plottet vi skal lage. 
nx = 50
ny = 50 

#Definerer lengden til hver grid
dx= 10
dy = 10

#Ettersom hvilket materiale vi velger vil det ha ulikt termisk diffusivitet
#kobber har 116 mm2/s i termisk diffusivitet som er relativt høy. vi skal bruke det.

alpha = 116

#definerer tidssteg og antall tid tidssteg
dt = 0.2
nt=200

#Juster gjerne på dx, dy og dt, men vær forsiktig siden ellers blir ting litt stygt. ellers skal du kunne drive å bytte verdier

#vi lager en plate og setter den lik 0 i grader. Deretter gir setter vi en varmflekk i midten, dette vil være start betingelsen vår.

plate = np.zeros((nx,ny))
plate[nx//2-5:nx//2+5,ny//2-5:ny//2+5]=500

#skal dermed oppdatere platen sin temperatur etterhvert som det går tid. Her setter vi randkravene slik at begge endene er 0.
#Bruker  finitt differansemetode
def Oppdater_plate_temp(plate):
    new_plate = plate.copy()
    for i in range(1,nx-1):
        for j in range(1,ny-1): #ser her at jeg ignorerer det først og siste objektet siden det skal alltid være 0
            new_plate[i,j]=plate[i,j] + alpha*dt*((plate[i+1,j]-2*plate[i,j]+plate[i-1,j])/dx**2 + (plate[i,j+1]-2 * plate[i,j]+plate[i,j-1])/dy**2)


    # Neumann-randbetingelser (null deriverte ved kantene)
    new_plate[0, :] = new_plate[1, :]   # Øvre kant
    new_plate[-1, :] = new_plate[-2, :] # Nedre kant
    new_plate[:, 0] = new_plate[:, 1]   # Venstre kant
    new_plate[:, -1] = new_plate[:, -2] # Høyre kant
    return new_plate

fig = plt.figure()
ax = fig.add_subplot(111, projection ='3d')
X,Y = np.meshgrid(np.arange(nx),np.arange(ny))

ax.set_zlim(0, 500)

def animate(frame):
    global plate
    plate = Oppdater_plate_temp(plate)
    ax.clear()
    ax.plot_surface(X, Y, plate, cmap='inferno')
    ax.set_title(f"Tid: {frame * dt:.2f}s")
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Temperatur')


ani = FuncAnimation(fig, animate, frames=nt, interval=50)
plt.show()